package com.example.ticketbook.bean;

import java.util.List;

public class MemberBean {
    public String name;
    public String userid;
    public int userNum;
    public String phoneNum;
    public List<NoticeBean> noticeList;
}
